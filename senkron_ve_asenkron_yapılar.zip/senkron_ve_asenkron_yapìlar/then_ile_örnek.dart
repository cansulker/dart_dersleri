//1-)Bir fonksiyon yazın bu fonksiyon aldığı id parametresine göre bir kullanıcı getirsin. Bu işlem 2 saniye sonunda sonuçlanacaktır ve getirilen kişi bilgisi map olarak alınacaktır. 
//Bu map yapısında username ve id bilgisi olması yeterli. 2-)Getirilen kişi bilgisindeki username değerini kullanarak kişinin kurslarını getiren bir fonksiyon yazın. 
//Bu fonksiyon 4sn sürecektir ve username değerine ait olan kursları içinde kursun adları olan bir liste olarak döndürecektir. 3-)Son olarakta kurslar listesindeki ilk elemanı parametre 
//olarak alan ve bu kursa ait bir yorumu döndüren bir fonksiyon yazın. Bu fonksiyon 1 sn sürecektir.
main(List<String> args) {
  /* String username = "";
  idyeGoreUserGetir(5).then((value) {
    print(value);
    username= value["username"]; // 2.kısımda ilk mapten gelecek username kullanılması gerektiğinden bu şekilde map içindeki username'e ulaşıp onu username adlı bir değişkene eşitliyoruz.
  });

  userNameKurslariGetir(username).then((value) => print(value)); //bu şekilde ilk fonksiyondan aldığımız usernameleri kullanarak ekrana o kişinin kursunu yazdırabiliriz. Bu kısmı dışarda yazdığımız zaman username beklemeden ekrana yazdırır bu yüzden üsttekinin içerisine yerleştirmemiz lazım.
   */ //bu şekilde uzunca yazmak yerine aşağıdaki gibi kısaca ve daha anlaşılır bir biçimde yazabiliriz. Bu kısım neyin nerden geldiğini anlamak için.

  idyeGoreUserGetir(5).then((value) {
    print(value); //value içindekini gösterir
    userNameKurslariGetir(value["username"]).then((List kurslarListesi) {
      print(kurslarListesi); //tüm kursları gösterir
      ilkKursunYorumu(kurslarListesi[0]).then((value3) {
        print(kurslarListesi[0]);//ilk kursu gösterir.
        return print(value3);
      }); 
    });
  });

  


}
//1.kısım için oluşturulan fonksiyon
Future<Map<String,dynamic>> idyeGoreUserGetir(int id) {
  print("$id idli kullanıcı getiriliyor");
  return Future<Map<String,dynamic>>.delayed(Duration(seconds: 2), (){
    return {"username": "cansulker", "id": id};
  });
}

//2.kısım için oluşturulan fonksiyon
Future<List<String>> userNameKurslariGetir(String usernme){
  print("$usernme adlı kullanıcının kursları getiriliyor.");
  return Future<List<String>>.delayed(Duration(seconds: 4), () {
    return ["flutter","kotlin","java"];
  });
}

//3.kısım için oluşturulan fonksiyon
Future ilkKursunYorumu(String kurs){
  print("İlk kurs getiriliyor");
  return Future.delayed(Duration(seconds: 1),() {
    return ("bu kurs çok verimli");
  });
}