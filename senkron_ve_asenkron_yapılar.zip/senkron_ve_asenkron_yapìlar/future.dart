//senkron ve asenkron kavramları
import 'dart:io';

main(List<String> args) {
  //Senkron Yapılar
  
  print("anne cocugu ekmek almaya yollar");
  uzunSurenIslem();
  print("peynir zeytin hazırlanır");//fonksiyon geçmeden bu adımları yapmaz.
  print("kahvaltı hazır");
  
}

/* void uzunSurenIslem() {
  print("çocuk ekmek almak için evden çıkar");
  sleep(Duration(seconds: 10));
  print("çocuk ekmekle eve girer."); */ //10sn bekeldikten sonra bunu ekrana yazdırır.

  //Asenkron Yapılar
 void uzunSurenIslem() {
  print("çocuk ekmek almak için evden çıkar");
  Future.delayed(Duration(seconds: 10),() //bu kod sayesinde beklerken main kısmındaki diğer işlemlere geçiş yapar.
    {print("çocuk ekmekle eve girer."); //10sn bekeldikten sonra bunu ekrana yazdırır.
  });
}