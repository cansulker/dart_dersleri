main(List<String> args) {
  print("internetten kişi verisi getirilecek");
  kisiyleIlgiliIslemler(); //fonksiyon tetiklendi ve işlem bittiği zaman ekrana yansıtacak bu sırada aşağıdaki işlemlere devam edecek.
  print("başka işler yapılacak");
  print("işlem bitti");
}
//fonksiyon olarak değilde main içinde yazsaydık eğer program sürenin bitmesini bekleyecek ve sonra devam edecekti bunu istediğimiz zamanlar olabilir ama istemediğimiz zaman bu şekilde yapmalıyız.
Future<void> kisiyleIlgiliIslemler() async { //await olan her fonksiyon başında async olmalı.
  String kisi = await kisiVerisiniGetir();
  print(kisi.length);
}

kisiVerisiniGetir() {
  return Future<String>.delayed(Duration(seconds: 5),(){
    return "Kişi adı : Cansu ve id:100";
  });
}