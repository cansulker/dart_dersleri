main(List<String> args) async{
  Future toplam = Future((){
    int toplam =0;
    for (int i=0; i<1000000000; i++){  //işlem çok uzun süreceğinden future içersine yazdık ki ana programı engellemeden kenarda işlemi yapsın diye.
      toplam=toplam+i;
    }
    return toplam;
  });
  //toplam.then((value) => print(value));  yerine aşağıdaki gibide yazabiliriz.
  try {  //hataları bulmak istiyorsak await komutlarında try-catch kullanılıyor genel olarak.
    int forSonuc = await toplam;
    print("***** $forSonuc");
  } catch (e) { //hata bulursa ekrana yaazdırır.
    print(e);
  }
  
  print("program başladı");
  Future.delayed(Duration(seconds: 0), (){ //işlem sıfır sn olsa bile future yaptığımız zaman farklı bir alana yolluyor program buda önce mainin bitmesini sonra bu açılan yere dönmesini sağlıyor.
    print("sıfır saniyelik işlem"); //Bu nedenle 0sn bile olsa min içersindekilrden sonra görücez bu yazıyı.
  });
  print("program bitti");

  

  //not: mainde 2tane future var ise ilk yazılan future yaptıktan sonra diğerini getiriyor.Süre farketmeksizin.
  
}