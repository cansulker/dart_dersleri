main(List<String> args) async{
  Map <String,dynamic> gelenUSer = await idyeGoreUserGetir(6); //fonksiyon üstüne gelip ne değr alıyormuş görebiliriz başına o şekilde tanımlama yapılabilir hiç bilmiyorsak var diyebiliriz.
  List kurslarListesi = await userNameKurslariGetir(gelenUSer["username"]);
  String yorum = await ilkKursunYorumu(kurslarListesi[0]);
  print(yorum);
  
}

//1.kısım için oluşturulan fonksiyon
Future<Map<String,dynamic>> idyeGoreUserGetir(int id) {
  print("$id idli kullanıcı getiriliyor");
  return Future<Map<String,dynamic>>.delayed(Duration(seconds: 2), (){
    return {"username": "cansulker", "id": id};
  });
}

//2.kısım için oluşturulan fonksiyon
Future<List<String>> userNameKurslariGetir(String usernme){
  print("$usernme adlı kullanıcının kursları getiriliyor.");
  return Future<List<String>>.delayed(Duration(seconds: 4), () {
    return ["flutter","kotlin","java"];
  });
}

//3.kısım için oluşturulan fonksiyon
Future ilkKursunYorumu(String kurs){
  print("İlk kurs getiriliyor");
  return Future.delayed(Duration(seconds: 1),() {
    return ("bu kurs çok verimli");
  });
}