main(List<String> args) {
  print("anne çocuğu ekmek almaya yollar");
  print("çocuk ekmek almak için evden çıkar");
  Future<String>sonuc=uzunSurenIslem();

  sonuc.then((String value) => print(value)).catchError((hata){
    print(hata);  // eğer bir hata olursa cathError komutu yakalayıp ne istiyorsak ekrana yazdırır.
  }).whenComplete(() => print("ekmek alma operasyonu bitti")); //bu sayede başarılı şekilde veri gelirse then 2sn sonra döndürülen kod ekrana yazdırırlır.
    

  print("peynir zeytin hazırlanır");
  print("kahvaltı hazır!");

}


Future<String> uzunSurenIslem(){
  Future<String> sonuc = Future.delayed(Duration(seconds: 2), (){
    //return "çocuk ekmekle eve girer";
    throw Exception("bakkalda ekmek kalmamış"); //eğer bir hata varsa onu bu şekilde gösterebiliriz.
  });
  return sonuc;
}
