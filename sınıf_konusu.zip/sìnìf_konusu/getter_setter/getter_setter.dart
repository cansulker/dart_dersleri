import 'Musteri.dart';

main(List<String> args) {
  var m1 = Musteri(123);
  m1.bilgileriYazdir();
  m1.musteriNoAta=452; //fonksiyon çağırmak yerine setter'larda bu şekilde ifadeyi eşitliyoruz.
  print(m1.musteriNoSoyle); // direkt ekrana getter sayesinde yazdırabildik.

  Musteri m2=Musteri(-568);
  m2.bilgileriYazdir();
  
}