class Musteri {
  int? _musteriNo;

  Musteri (int musteriNo){
    _musteriNoKontrol(musteriNo);
  }

  String get musteriNoSoyle {
    return "Musteri no : $_musteriNo";
  } //ekrana yazdırmak için kullanıyoruz.

  String get musteriNoSoyle2 => "Musteri no : $_musteriNo"; // bu şekilde tek satırda yazabiliyorduk.

  void set musteriNoAta (int no){
    if(no>0){  //müşteri numarası negatif sayı olamayacağından böyle bir kontrol yapıyoruz.
      _musteriNo = no;
    }else {
      return;
    }
  }
  //Bir veri atamaya yarayan fonksiyonlara setter denir. Aşağıdaki fonksiyonun yaptığını setter'lar ile yapabiliyoruz.

  void _musteriNoKontrol(int no){
    if(no>0){  //müşteri numarası negatif sayı olamayacağından böyle bir kontrol yapıyoruz.
      _musteriNo = no;
    }else {
      return;
    }
  }

  void bilgileriYazdir(){
    print("Müşteri oluşturuldu, müşteri no: $_musteriNo");
  }
}