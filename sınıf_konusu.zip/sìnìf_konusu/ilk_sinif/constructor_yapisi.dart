main(List<String> args) {
  Araba honda =Araba(2020,"Honda",true);// bu kısım çağrıldığı zaman ekrana kurucumetod tetiklendi yazacak çünkü constructor metod bu adımda devreye giriyor.
  /* honda.marka="Honda";
  honda.modelYili=2020;
  honda.otomatikMi=true; */
  honda.bilgileriSoyle();// burada sınıf içindeki metodu çağrıyoruz.
  honda.yasHesapla(); 

  var bmw= Araba(2021,"BMW", true);
  bmw.bilgileriSoyle();
  bmw.yasHesapla();

  var citroen = Araba.markasizKurucuMetod(false, 2019);
  Araba toyota = Araba.yiliOlmayanKurucuMetod("toyota", false);

  citroen.bilgileriSoyle();
  toyota.bilgileriSoyle();
  toyota.yasHesapla(); // model yılı olmadığı için hata verecekti ama aşağıda metod içersine yazdığımız koşul sayesinde program hatasından kurtuluyoruz.
}

class Araba {
  int? modelYili;  //burada tanımlı olan ifadelerdeki değerler aşağıdaki fonksiyonlarda kullanılacaktır. Bu yüzden consructor kısmında istenilen değerleri buradakilerle eşitlememiz lazım. 
  String? marka;  //yukarıda alınan ifadeler direkt olarak constructor ifade içersindeki değişkenlere gidiyor aynı isimde olmaları her yerde kullanılacak anlamına gelmez bu yüzden bu ifadeleri
  bool? otomatikMi; //birbirlerine eşitlememiz lazım bunuda "this" ifadesi ile yapıyoruz.

  //Constructor metod deniyor buna çağırmasan bile gizli olarak otomatik bu işlemi yapıyor sen sınıfı oluşturduğunda.
  /*Araba (){
    print("Kurucu metot tetiklendi");
  }*/ // bir sınıfta sadece 1 tane constructor metod olabilir.
  /* Araba(int modelYili,String marka, bool otomatikMi){  
    print("Kurucu metod tetiklendi");
    this.modelYili=modelYili; //sınıf içerisindeki ifadeye yukarıdan aldığımız ifadeyi this yardımı ile eşitliyoruzki kullanabilelim.
    this.marka=marka;  //değişken isimleri aynı olduğu için this kullanıyoruz. Farklı isimler olsaydı direkt eşitleyebilirdik. Ama genelde aynı isimler kullanılır.
    this.otomatikMi=otomatikMi;
  } */
  Araba(this.modelYili,this.marka,this.otomatikMi){ //bu şekilde tek satırda atamamızı yapabiliriz.
    print("Kurucu metot tetiklendi");
  }
  //Aşağıdaki gibi Named Contructor metod oluşturabiliriz. Bu sayede birden fazla constructor oluşturabiliyoruz. Bunun amacı değişkenlerden bazılaını yazmak istemediğimiz zaman bunları kullanabiliriz.
  Araba.markasizKurucuMetod(this.otomatikMi,this.modelYili); 
  Araba.yiliOlmayanKurucuMetod(this.marka,this.otomatikMi);

  void bilgileriSoyle() {
    print("Arabanın model yılı $modelYili , markası: $marka , otomatik mi : $otomatikMi");
  }

  void yasHesapla(){
    if (modelYili != null)
    print("Arabanın yaşı ${2021-modelYili!}"); //ünlem işareti gelecek ifade null olmayacak sen bunu kullanabilirsin demek.
    else
      print("model yılı olmadığından hesaplanamadı");
  }
}