class OgrenciSinifi {
  int ogrNo=1;
  String? ogrAd; //ifade null olabilir diyoruz yoksa hata veriyor.
  bool? aktifMi;

  void dersCalis(){ //sınıf içersine fonksiyon yaratabiliriz.Bunlara metod denir.
    print("Öğrenci ders çalışıyor");
  }
}

main(List<String> args) {
  OgrenciSinifi cansu = OgrenciSinifi(); // bu şekilde sınıf çağrılır.
  cansu.ogrAd="Cansu Ülker"; //bu şekilde sınıftaki ifadeler çağrılabilir.
  cansu.ogrNo=311;
  var ron = OgrenciSinifi();//bu şekilde de sınıf olşturabiliriz.
  ron.dersCalis();

  
}


