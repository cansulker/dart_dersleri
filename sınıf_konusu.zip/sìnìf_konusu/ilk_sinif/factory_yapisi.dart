//constructor'larda return kullanamayız ama factory yapısı sayesinde return komutu kullanılabiliyor.
import 'ilk_sinif_ornegi.dart';

main(List<String> args) {
  Ogrenci ezgi = Ogrenci(5,"ezgi");
  Ogrenci mehmet = Ogrenci.idSiz("mehmet");
  Ogrenci turgay = Ogrenci.factoryKurucusu(-9, "turgay");

  print(turgay.id); // negatif değer verdiğimiz için factory kısmında geriye 5 döndür koşulu devreye girecek ve ekrana 5 yazdıracak.
  print(turgay.isim);

}

class Ogrenci {
  int id = 0;
  String isim = "";

  Ogrenci(this.id, this.isim) {
    print("varsayılan kurucu çalıştı"); 
    // return Ogrenci(id,isim) bu şekilde return kullanamayız hata verir. Return kullanmak istiyorsak factory kullanıcaz.
  }
  Ogrenci.idSiz(this.isim) {
     print("isimlendirilmiş kurucu çalıştı");
  }

  factory Ogrenci.factoryKurucusu( int id, String isim) {
    if (id< 0){
      return Ogrenci(5,isim); // verilen id 0'dan küçükse 5 olarak geri döndürücek.
    } else {
      return Ogrenci(id,isim); //koşul doğruysa aynılarını döndürücek.
    }

  }



}