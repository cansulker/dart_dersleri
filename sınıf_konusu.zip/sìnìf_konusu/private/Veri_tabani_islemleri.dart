import 'dart:math';

class VeritabaniIslemleri {
  String _kullaniciAdi = "gezegen"; // private yapmak istediğimiz zaman "_" kullanuyoruz. Sınıfı main ile aynı yerde yazarsak private özelliği geçerli olmaz.
  String _sifre = "123456";

  bool baglan(){
    if (_internetVarmi()){
      if (_kullaniciAdi == "gezegen" && _sifre == "123456") {
        return true;
      }else 
      return false;
      }else {
        return false;
      }
  }

  VeritabaniIslemleri(){ // bunu oluşturmamız gerekiyor çünkü mainde sınıf çağrıldığı zaman otomatik bu devreye giriyor.
        //Biz aşağıda isimlendirilmiş Constructor kullandığımızdan normal Constructor ifadesinide hata almamak için belirtmemiz gerekiyor. 
  }  //Eğer isimlendirilmiş kullanmasaydık bunuda yazmamıza gerek olmayacaktı.
  
  VeritabaniIslemleri.loginWithNamedandPassword(String kullaniciAd,String sifre){

  }

  bool _internetVarmi (){ //sınıf çağrıldığı zaman bunu kullanıcının görmesine gerek yok çünkü amacımız sadece bağlanı kullanmak. O yüzden burayı private yapıyoruz.
    if(Random().nextBool()){
      return true;
    }else
      return false;
  }
}