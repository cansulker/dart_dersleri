import 'Veri_tabani_islemleri.dart';

main(List<String> args) {
  VeritabaniIslemleri db =VeritabaniIslemleri();

  VeritabaniIslemleri.loginWithNamedandPassword("gezegen", "123456");

  

  bool sonuc = db.baglan();
  if (sonuc){  //otomatik true olarak algılıyor zaten
    print("bağlandım");
  }else {
    print("bağlanamadım");
  }
}