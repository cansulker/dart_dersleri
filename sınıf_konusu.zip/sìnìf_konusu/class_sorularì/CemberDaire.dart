class CemberDaire{
  int? _yariCap;
  double _pi=3.14;
  

  CemberDaire(int yariCap){
    print("kurucu metod oluşturuldu");
    _yariCapKontrol=yariCap;
  }

  void set _yariCapKontrol(int deger){
    if(deger>0){
      _yariCap=deger;
    }else{
      _yariCap=1;
    }
  }

  void cevreHesapla(){
    
    double cevre = 2*_pi*_yariCap!;
    print("Dairenin çevresi= $cevre");   
  }

  void alanHesapla(){
    print("Dairenin alanı= ${_pi*_yariCap!*_yariCap!}");
  }
}