
import 'dart:math';
import 'CemberDaire.dart';
import 'Ogrenci.dart';


main(List<String> args) {
  // CemberDaire isimli bir sınıf oluşturun. Bu sınıfın yarıçap alan kurucusu olmalı. Ayrıca cevre ve alanını hesaplayan metodları olmalı(pi=3.14).
  print("************** Soru 1 **************");
  var daire = CemberDaire(-3);
  daire.alanHesapla();
  daire.cevreHesapla();

  //Ogrenci isimli sınıf oluşturun.Bu sınıfta öğrencinin id'si ve not değeri tutulmalı. 100 elemanlı bir listede id ve not değerlerini rastgele oluşturarak bu öğrencileri saklayın 
  //ve bu öğrencileri yazdıran metodu yazın.
  print("************** Soru 2 **************");

  Ogrenci ogr1 =Ogrenci(id:5,not:10);
  List<Ogrenci> tumOgrenciler = List.filled(100, Ogrenci());

  ogrenciListesiniDoldur(tumOgrenciler);
  for(Ogrenci oankiOgrenci in tumOgrenciler){
    print(oankiOgrenci);
  }

  print("Tüm öğrencilerin ortalaması"+ortalama(tumOgrenciler).toString());

  
  
}

void ogrenciListesiniDoldur(List<Ogrenci> liste) {
  for (int i=0;i<liste.length;i++){
      liste[i]= Ogrenci(id:Random().nextInt(1000), not:Random().nextInt(100));
    }
}


//ekstradan yazdık
double ortalama(List<Ogrenci> liste){
  int toplam=0;
  for(Ogrenci oankiOgrenci in liste){
    toplam=toplam+oankiOgrenci.not;
  }
  return toplam/liste.length;
  
}